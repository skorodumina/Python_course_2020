
extern "C" {
void wave_propogation_(int *num_steps, int *scale, float *damping,
                       float *initial_P, int *stop_step, float *_P);
}
