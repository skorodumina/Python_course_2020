# Python for STEM Course 2020

Welcome to the University of South Carolina Python for STEM Course Summer 2020. Please proceed to the `01_Week1` folder if you are a participant in the Week 1-Beginner segment of the course. Please proceed to the `02_Week2` folder if you are a participant in the Week 2-Advanced segment of the course. 

# Instructors

Doug Adams: [@douglasquincyadams](https://github.com/douglasquincyadams) | [da2@email.sc.edu](da2@email.sc.edu)

Ellie Davis: [@daviseleanorj](https://github.com/daviseleanorj) | [eleanord@email.sc.edu](eleanord@email.sc.edu)

Justin Pierel: [@jpierel14](https://github.com/jpierel14) | [jr23@email.sc.edu](jr23@email.sc.edu)

Steve Rodney: [@srodney](https://github.com/srodney) | [srodney@sc.edu](srodney@sc.edu)

Nick Tyler: [@tylern4](https://github.com/tyler4) | [tylerns@email.sc.edu](tylerns@email.sc.edu)

Benedicth Ukhueduan: [ukhuedub@email.sc.edu](ukhuedub@email.sc.edu)


