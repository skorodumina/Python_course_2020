# Welcome to Day 3 of Python for STEM!

## Day 3 - Loops and Packages
* 8:30 Introduction to for/while loops
* 9:00 Fixing/writing loops   
* 10:00 Introduction to Python packages
* 10:30 Simple Numpy, Pandas, Matplotlib usage
* 11:45 Wrap up

### 04_Loops
* Introduction to `for` and `while` loops 