# Welcome to Day 4 of Python for STEM!

## Day 4 - Useful Pandas Applications
* 8:30  Examples of Pandas usages
* 9:00  Activities implementing Pandas
* 11:45 Wrap up

### 06_PandasIMDB
* More in-depth use of the Pandas package for data analysis