# Welcome to the First Day of the Python for STEM Beginner Week!

# Day 1 Schedule - Introduction to Python
* 8:30  Introductions, Overview of the week
* 8:50  Getting repl.it set up (accessing the resources)
* 9:30  Understanding Python Vocabulary
* 10:45  Reading Python Programs
* 11:45  Wrap up

# Below are links to the resources for the day

## [Introductory Presentation](https://docs.google.com/presentation/d/1Ax2IB1lcuJM9RdKISdMi-7wqaAQw2k2Mx8cbfvd9AcU/edit?usp=sharing)
## [Vocabulary Breakout Groups Document](https://docs.google.com/presentation/d/1WZp9upfId1k8lAF4t4pGZvaM-YnZtBShKLLWFexOTwQ/edit?usp=sharing)
## See Presentation for additional activities