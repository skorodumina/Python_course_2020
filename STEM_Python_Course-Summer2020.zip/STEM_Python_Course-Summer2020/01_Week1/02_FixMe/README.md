# Welcome to Day 2 of Python for STEM!

## Day 2 - Documentation and Understanding Errors
* 8:30  Introducing documentation/Stack Overflow
* 9:30  Identifying and fixing errors
* 10:30  Writing a working program
* 11:45 Wrap up

### 02_FixMe
* Activities aimed at having participants fix broken and/or misbehaving code to learn error handling and useful documentation