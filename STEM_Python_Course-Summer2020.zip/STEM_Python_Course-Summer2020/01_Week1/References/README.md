# References

Here you'll find a reference for using `git`, as well as a code reference that should give lots of useful code and definitions for using Python. If you would like to watch some videos to help learn more about any specific part of Python, [here is a compilation of useful videos](https://docs.google.com/document/d/1XMUe2EIJVfO8lMc_Lagh3TkGVLGJoNrBQ2Qp3qSpai0/edit?usp=sharing). 