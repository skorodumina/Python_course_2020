### Day 1: Introduction Tutorial

*Folder contents:* Jupyter notebooks and required supplementary files for the Python introduction tutorial.

**Jupyter notebooks:**
- Day1_tutorial.ipynb
- Day1_exercises.ipynb
- Day1_solutions.ipynb

**Required files:**
- day1.txt
- mass.csv
- may2019_temps.csv
- periodictable.csv
